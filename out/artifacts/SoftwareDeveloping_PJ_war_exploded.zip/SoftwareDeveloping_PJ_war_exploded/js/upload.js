function upload() {
    document.getElementById("myForm").submit();
}
